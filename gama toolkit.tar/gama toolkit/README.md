# GAMA ToolKit

GAMA ToolKit is a CLI-based cybersecurity toolkit designed for penetration testing and security assessments. 
It integrates multiple tools into a single interface with a phased workflow.

## Features

1.CLI-Based Interface** – User-friendly command-line interface with color-coded text for clarity.  
2.Phased Cybersecurity Workflow** – Organized into Reconnaissance, Scanning, Enumeration, Exploitation, Post-Exploitation, and Reporting.  
3.Cross-Linux Compatibility** – Runs on all major Linux distributions using a safe Python virtual environment.  
4.Virtual Environment Setup** – `setup.py` automates venv creation and installs core dependencies like `impacket` and `csvkit`.  
5.Modular & Extensible** – Easy to add new tools in each phase without modifying core code.  
6.System-Friendly** – Low resource usage: ~2 GB RAM recommended, any modern CPU, and ~500 MB storage for Python, virtual environment, and basic tools (more if using OpenVAS or MSFConsole).  


## Advice
Most tools require administrative privileges (sudo) or elevated rights to run fully.
Run and install in privilege(sudo) mode


##  How to Install GAMA_toolkit using cmd
1. Unzip the folder**  
	sudo unzip gama_toolkit.zip
2.Navigate into the folder
	cd gama_toolkit
3.Give execute permissions
	chmod +x gama_toolkit.py setup.py
4.Run the setup file, This will create a Python virtual environment and install required libraries:
	sudo python3 setup.py
5.Activate the virtual environment before using Python-based tools:
	source gama_venv/bin/activate
6.Run the GAMA ToolKit
	sudo python3 gama_toolkit.py

