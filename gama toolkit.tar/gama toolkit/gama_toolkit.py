#!/usr/bin/env python3
import os
import sys
import urllib.request

# Colors
GREEN = "\033[92m"
RESET = "\033[0m"

# ================= Banner =================
def banner():
    # Banner displays only the text "GAMA ToolKit" in stylized ASCII
    print(rf"""{GREEN}
   	 		 ██████╗  █████╗ ███╗   ███╗ █████╗     
  			██╔════╝ ██╔══██╗████╗ ████║██╔══██╗    
  			██║  ███╗███████║██╔████╔██║███████║      
  			██║   ██║██╔══██║██║╚██╔╝██║██╔══██║      
  			╚██████╔╝██║  ██║██║ ╚═╝ ██║██║  ██║     
   	 		 ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝       
                G A M A   T o o l K i t
{RESET}""")

# ================= Update Function =================
def update_gama():
    print(f"{GREEN}[*] Checking for latest version...{RESET}")
    # Replace with your actual raw URL if hosted on GitHub/Gitlab/etc.
    url = "https://github.com/mjai-cy/gama-toolkit.git"
    try:
        with urllib.request.urlopen(url) as response:
            new_code = response.read()
        with open(sys.argv[0], "wb") as f:
            f.write(new_code)
        print(f"{GREEN}[✓] GAMA ToolKit has been updated! Please restart the toolkit.{RESET}")
        sys.exit(0)
    except Exception as e:
        print(f"{GREEN}[!] Update failed: {e}{RESET}")

# ================= Phases =================
def reconnaissance():
    while True:
        print(f"{GREEN}=== Reconnaissance ==={RESET}")
        print(f"{GREEN}1. Amass\n2. TheHarvester\n3. DNSenum\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        target = input(f"{GREEN}Enter target domain/IP: {RESET}").strip()
        if choice == "1":
            os.system(f"amass enum -d {target}")
        elif choice == "2":
            os.system(f"theHarvester -d {target} -b all")
        elif choice == "3":
            os.system(f"dnsenum {target}")
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

def scanning():
    while True:
        print(f"{GREEN}=== Scanning ==={RESET}")
        print(f"{GREEN}1. Nmap\n2. Masscan\n3. Rustscan\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        target = input(f"{GREEN}Enter target IP/domain: {RESET}").strip()
        if choice == "1":
            os.system(f"nmap {target}")
        elif choice == "2":
            os.system(f"masscan {target}")
        elif choice == "3":
            os.system(f"rustscan -a {target}")
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

def enumeration():
    while True:
        print(f"{GREEN}=== Enumeration ==={RESET}")
        print(f"{GREEN}1. enum4linux\n2. ldapsearch\n3. Impacket\n4. OpenVAS\n5. Nikto\n6. Nmap\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        target = input(f"{GREEN}Enter target IP/domain: {RESET}").strip()
        tools = {
            "1": f"enum4linux {target}",
            "2": f"ldapsearch -h {target}",
            "3": f"impacket-smbclient {target}",
            "4": f"openvas -T {target}",
            "5": f"nikto -h {target}",
            "6": f"nmap {target}"
        }
        if choice in tools:
            os.system(tools[choice])
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

def exploitation():
    while True:
        print(f"{GREEN}=== Exploitation ==={RESET}")
        print(f"{GREEN}1. msfconsole\n2. sqlmap\n3. commix\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        target = input(f"{GREEN}Enter target URL/IP: {RESET}").strip()
        tools = {
            "1": "msfconsole",
            "2": f"sqlmap -u {target} --batch",
            "3": f"commix -u {target} --batch"
        }
        if choice in tools:
            os.system(tools[choice])
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

def post_exploitation():
    while True:
        print(f"{GREEN}=== Post-Exploitation ==={RESET}")
        print(f"{GREEN}1. CrackMapExec\n2. Impacket\n3. Mimikatz\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        target = input(f"{GREEN}Enter target IP/domain: {RESET}").strip()
        tools = {
            "1": f"crackmapexec smb {target}",
            "2": f"impacket-smbclient {target}",
            "3": "mimikatz"
        }
        if choice in tools:
            os.system(tools[choice])
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

def reporting():
    while True:
        print(f"{GREEN}=== Reporting ==={RESET}")
        print(f"{GREEN}1. jq\n2. csvkit\n3. pandoc\n0. Back to Main Menu{RESET}")
        choice = input(f"{GREEN}Select a tool: {RESET}").strip()
        if choice == "0":
            return
        file_path = input(f"{GREEN}Enter file path: {RESET}").strip()
        tools = {
            "1": f"jq . {file_path}",
            "2": f"csvlook {file_path}",
            "3": f"pandoc {file_path} -o report.pdf"
        }
        if choice in tools:
            os.system(tools[choice])
        else:
            print(f"{GREEN}Invalid choice!{RESET}")

# ================= Main Menu =================
def main_menu():
    while True:
        print(f"\n{GREEN}1. Reconnaissance\n2. Scanning\n3. Enumeration\n4. Exploitation\n5. Post-Exploitation\n6. Reporting\n0. Exit\n7. Update GAMA ToolKit{RESET}")
        choice = input(f"{GREEN}Select a phase (0-7): {RESET}").strip()
        if choice == "0":
            print(f"{GREEN}Exiting GAMA ToolKit. Goodbye!{RESET}")
            sys.exit(0)
        elif choice == "1":
            reconnaissance()
        elif choice == "2":
            scanning()
        elif choice == "3":
            enumeration()
        elif choice == "4":
            exploitation()
        elif choice == "5":
            post_exploitation()
        elif choice == "6":
            reporting()
        elif choice == "7":
            update_gama()
        else:
            print(f"{GREEN}Invalid choice! Please select a number from 0 to 7.{RESET}")

# ================= Run =================
if __name__ == "__main__":
    os.system("clear")
    banner()
    main_menu()
