#!/usr/bin/env python3

import os
import sys
import subprocess
import shlex

VENV_DIR = "gama_venv"
PY_PKGS = ["impacket", "csvkit"]

# Helper ------------------------------------------------
def run(cmd, check=False, shell=False):
    if isinstance(cmd, str) and not shell:
        cmd = shlex.split(cmd)
    return subprocess.run(cmd, check=check, shell=shell)

# Detect package manager
def detect_pkg_manager():
    if os.path.exists("/etc/debian_version"):
        return "apt"
    if os.path.exists("/etc/fedora-release") or os.path.exists("/etc/redhat-release"):
        return "dnf"
    if os.path.exists("/etc/arch-release"):
        return "pacman"
    return None

# Install system build deps (only if running as root)
def install_system_build_deps():
    pkg = detect_pkg_manager()
    if not pkg:
        print("[!] Could not detect package manager. Please install system build deps manually if needed.")
        return

    print(f"[*] Detected package manager: {pkg}")
    if pkg == "apt":
        deps = "build-essential libssl-dev libffi-dev python3-dev libldap2-dev libsasl2-dev git curl"
        cmd = ["apt", "update", "-y"]
        print("[*] Running apt update (you are root)...")
        run(cmd, check=False)
        print("[*] Installing system build packages (apt)...")
        run(["apt", "install", "-y"] + deps.split(), check=False)
    elif pkg == "dnf":
        deps = "gcc gcc-c++ openssl-devel libffi-devel python3-devel openldap-devel git curl"
        print("[*] Installing system build packages (dnf)...")
        run(["dnf", "install", "-y"] + deps.split(), check=False)
    elif pkg == "pacman":
        deps = "base-devel openssl libffi python python-pip git curl"
        print("[*] Installing system build packages (pacman)...")
        run(["pacman", "-Syu", "--noconfirm"] + deps.split(), check=False)

# Create or reuse venv
def create_or_activate_venv():
    if not os.path.exists(VENV_DIR):
        print("[*] Creating Python virtual environment...")
        run([sys.executable, "-m", "venv", VENV_DIR], check=True)
    else:
        print("[*] Virtual environment already exists.")
    pip_path = os.path.join(VENV_DIR, "bin", "pip")
    if not os.path.exists(pip_path):
        print("[!] pip not found in venv. Something went wrong with venv creation.")
        sys.exit(1)
    print("[✓] Virtual environment ready.")
    print(f"[*] To use GAMA later: source {VENV_DIR}/bin/activate")

# Install python packages inside venv
def install_python_packages():
    pip_path = os.path.join(VENV_DIR, "bin", "pip")
    print("[*] Upgrading pip, setuptools, wheel inside venv...")
    run([pip_path, "install", "--upgrade", "pip", "setuptools", "wheel"], check=True)
    print("[*] Installing Python packages inside venv:", " ".join(PY_PKGS))
    try:
        run([pip_path, "install"] + PY_PKGS, check=True)
        print("[✓] Python packages installed.")
    except subprocess.CalledProcessError as e:
        print("[!] pip install failed inside venv. See error above.")
        print("    Common fixes:")
        print("     - Ensure system build deps are installed (see instructions below).")
        print("     - Activate venv and run: pip install impacket csvkit")
        raise

# Try to install crackmapexec via pipx if user wants (best-effort)
def try_crackmapexec_pipx_trial():
    print("\n[*] CrackMapExec is not installed by default by this script.")
    print("    CrackMapExec often requires distro packages or pipx. Choose an option:")
    print("    1) Try to install pipx and CrackMapExec (user-level) now (recommended).")
    print("    2) Skip and show manual install instructions.")
    choice = input("Select 1 or 2 (default 2): ").strip() or "2"
    if choice == "1":
        try:
            print("[*] Installing pipx (user)...")
            # Use user pip to install pipx
            run([sys.executable, "-m", "pip", "install", "--user", "pipx"], check=True)
            # Ensure pipx binary location
            pipx_bin = os.path.expanduser("~/.local/bin/pipx")
            if not os.path.exists(pipx_bin):
                print("[!] pipx binary not found at ~/.local/bin/pipx. Please add ~/.local/bin to your PATH or install pipx manually.")
                return
            print("[*] Installing CrackMapExec via pipx from GitHub...")
            run([pipx_bin, "install", "git+https://github.com/byt3bl33d3r/CrackMapExec"], check=True)
            print("[✓] CrackMapExec installed via pipx (user-level).")
        except Exception as e:
            print(f"[!] pipx / CrackMapExec install failed: {e}")
            print("    You can still install CrackMapExec manually (see printed instructions).")

# Print manual instructions (clear)
def print_manual_instructions():
    print("\n=== Manual installation instructions (choose one) ===")
    print("A) On Kali/Parrot/Debian-based (system package):")
    print("   sudo apt update && sudo apt install -y crackmapexec")
    print("\nB) Using pipx (recommended user-level install):")
    print("   python3 -m pip install --user pipx")
    print("   python3 -m pipx ensurepath")
    print("   pipx install git+https://github.com/byt3bl33d3r/CrackMapExec")
    print("\nC) From source:")
    print("   git clone https://github.com/byt3bl33d3r/CrackMapExec.git")
    print("   cd CrackMapExec && python3 -m pip install .")
    print("======================================================\n")

# Main ----------------------------------------------------------------
def main():
    try:
        if os.geteuid() == 0:
            print("[*] Running as root — will try to install system build dependencies.")
            install_system_build_deps()
        else:
            print("[*] Not running as root. If pip install fails for impacket you may need to run the following as root:")
            print("    (Debian/Ubuntu) sudo apt update && sudo apt install -y build-essential libssl-dev libffi-dev python3-dev libldap2-dev libsasl2-dev git curl")
            print("    (Fedora) sudo dnf install -y gcc gcc-c++ openssl-devel libffi-devel python3-devel openldap-devel git curl")
            print("    (Arch) sudo pacman -Syu --noconfirm base-devel openssl libffi git curl")
        create_or_activate_venv()
        install_python_packages()
        print_manual_instructions()
        try_crackmapexec_pipx_trial()
        print("\nSetup finished.\nTo run GAMA ToolKit now:")
        print(f"  source {VENV_DIR}/bin/activate")
        print("  python3 gama.py")
    except subprocess.CalledProcessError as e:
        print(f"[!] An error occurred during setup: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
